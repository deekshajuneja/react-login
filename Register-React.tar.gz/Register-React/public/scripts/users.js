import Dropdown from 'react-dropdown'
const options = ['MA', 'IA']

//Creating new React Class here
var User = React.createClass({
  // A function
  rawMarkup: function() {
    // Remarkable Formatting
    var md = new Remarkable();
    //Rendering the application
    var rawMarkup = md.render(this.props.children.toString());
    // returning a value
    return { __html: rawMarkup };
  },

  render: function() {
    return (
      <div className="user">
        <h2 className="userRegister">
          Register Here
        </h2>
        <span dangerouslySetInnerHTML={this.rawMarkup()} />
      </div>
    );
  }
});

var UserBox = React.createClass({

  handleUserSubmit: function(user) {
    var users = this.state.data;
    user.id = Date.now();
    var newUsers = users.concat([user]);
    this.setState({data: newUsers});
    $.ajax({
      url: this.props.url,
      dataType: 'json',
      type: 'POST',
      data: user,
      success: function(data) {
        this.setState({data: data});
      }.bind(this),
      error: function(xhr, status, err) {
        this.setState({data: users});
        console.error(this.props.url, status, err.toString());
      }.bind(this)
    });
  },
  getInitialState: function() {
    return {data: []};
  },

  render: function() {
    return (
      <div className="userBox">
        <h1>Register Here</h1>
        <UserForm onUserSubmit={this.handleUserSubmit} />
      </div>
    );
  }
});

var UserForm = React.createClass({
  getInitialState: function() {
    return {firstname: '', lastname: '', address:'', phonenumber:'',
     email:'', licensestate:'', licensenum: ''};
  },
  handleFirstNameChange: function(e) {
    this.setState({firstname: e.target.value});
  },
  handleLastNameChange: function(e) {
    this.setState({lastname: e.target.value});
  },
  handleAddressChange: function(e) {
    this.setState({address: e.target.value});
  },
  handlePhoneNumberChange: function(e) {
    this.setState({phonenumber: e.target.value});
  },
  handleEmailAddressChange: function(e) {
    this.setState({email: e.target.value});
  },
  handleLicensePlateStateChange: function(e) {
    this.setState({licensestate: e.target.value});
  },
  handleLicensePlateNumChange: function(e) {
    this.setState({licensenum: e.target.value});
  },
  handleSubmit: function(e) {
    e.preventDefault();
    var firstname = this.state.firstname.trim();
    var lastname = this.state.lastname.trim();
    var address = this.state.address.trim();
    var phonenumber = this.state.phonenumber.trim();
    var email = this.state.email.trim();
    var licensestate = this.state.licensestate.trim();
    var licensenum = this.state.licensenum.trim();
    if (!firstname || !lastname || !address ||!phonenumber || !email || !licensestate || !licensenum) {
      return;
    }
    this.props.onUserSubmit({firstname: firstname, lastname: lastname, address: address, phonenumber: phonenumber,
        email: email, licensestate: licensestate, licensenum:licensenum});
    this.setState({firstname: '', lastname: '', address:'', phonenumber:'', email:'', licensestate:'', licensenum:''});
  },
  render: function() {
    return (
      <form className="userForm" onSubmit={this.handleSubmit}>
        <input
          type="text"
          placeholder="First name"
          value={this.state.firstname}
          onChange={this.handleFirstNameChange}
        />
        <input
          type="text"
          placeholder="Last name"
          value={this.state.lastname}
          onChange={this.handleLastNameChange}
        />
        <input
          type="text"
          placeholder="Address (Street, City, State, Zip)"
          value={this.state.address}
          onChange={this.handleAddressChange}
        />
        <input
          type="number"
          placeholder="Phone Number (999)-999-9999"
          value={this.state.phonenumber}
          onChange={this.handlePhoneNumberChange}
        />
        <input
          type="text"
          placeholder="Email Address"
          value={this.state.email}
          onChange={this.handleEmailAddressChange}
        />
//        <select value={this.state.selectValue}
//         onChange={this.handleLicensePlateStateChangeChange}
//         >
//            <option value={states}>{states}</option>
//          </select>
        <Dropdown options={options} onChange={this.handleLicensePlateStateChangeChange} value={defaultOption} placeholder="Select an option" />
        <input
          type="text"
          placeholder="License Plate (State-Number eg: MA-123456)"
          value={this.state.licensenum}
          onChange={this.handleLicensePlateNumChange}
        />
        <input type="submit" value="Post" />
      </form>
    );
  }
});


//
//var FruitSelector = React.createClass({
//    getInitialState:function(){
//        return {selectValue:'Orange'};
//    },
//    handleChange:function(e){
//        this.setState({selectValue:e.target.value});
//    },
//    render: function() {
//        var message='You selected '+this.state.selectValue;
//        return (
//        <div>
//         <select value={this.state.selectValue}
//         onChange={this.handleChange}
//         >
//            <option value="Orange">Orange</option>
//            <option value="Radish">Radish</option>
//            <option value="Cherry">Cherry</option>
//          </select>
//          <p>{message}</p>
//          </div>
//        );
//    }
//});
//
//React.render(<FruitSelector name="World" />, document.body);
//



ReactDOM.render(
  <UserBox url="./users" pollInterval={2000} />,
  document.getElementById('data')
);
