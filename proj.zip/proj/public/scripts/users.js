
var ziplist = ["02462", "02468", "02465", "02459"];
var otherservices = []
//Creating new React Class here
var User = React.createClass({
  // A function
  rawMarkup: function() {
    // Remarkable Formatting
    var md = new Remarkable();
    //Rendering the application
    var rawMarkup = md.render(this.props.children.toString());
    // returning a value
    return { __html: rawMarkup };
  },

  render: function() {
    return (
      <div className="user">
        <h2 className="userRegister">
          Register Here
        </h2>
        <span dangerouslySetInnerHTML={this.rawMarkup()} />
      </div>
    );
  }
});

var UserBox = React.createClass({
  handleUserSubmit: function(user) {
    var users = this.state.data;
    user.id = Date.now();
    var newUsers = users.concat([user]);
    this.setState({data: newUsers});
    $.ajax({
      url: this.props.url,
      dataType: 'json',
      type: 'POST',
      data: user,
      success: function(data) {
        this.setState({data: data});
      }.bind(this),
      error: function(xhr, status, err) {
        this.setState({data: users});
        console.error(this.props.url, status, err.toString());
      }.bind(this)
    });
  },
  getInitialState: function() {
    return {data: []};
  },
  render: function() {
    return (
      <div className="userBox">
        <h1>Submit a Service Request</h1>
        <UserForm onUserSubmit={this.handleUserSubmit} />
      </div>
    );
  }
});

var UserForm = React.createClass({
  getInitialState: function() {
    return {firstname: '', lastname: '', address:'', phonenumber:'',
     email:'', licensestate:'', licensenum: '', zip: '', service: '', otherservice:''};
  },
  handleFirstNameChange: function(e) {
    this.setState({firstname: e.target.value});
  },
  handleLastNameChange: function(e) {
    this.setState({lastname: e.target.value});
  },
  handleAddressChange: function(e) {
    this.setState({address: e.target.value});
  },
  handlePhoneNumberChange: function(e) {
    this.setState({phonenumber: e.target.value});
  },
  handleEmailAddressChange: function(e) {
    this.setState({email: e.target.value});
  },
  handleLicensePlateStateChange: function(e) {
    this.setState({licensestate: e.target.value});
  },
  handleLicensePlateNumChange: function(e) {
    this.setState({licensenum: e.target.value});
  },
  handleZipChange: function(e) {
    this.setState({zip: e.target.value});
  },
  handleServiceChange: function(e) {
    this.setState({service: e.target.value});
  },
  handleOtherServiceChange: function(e) {
    otherservices.push(e.target.value)
    this.setState({otherservice: otherservices});
  },
  handleSubmit: function(e) {
    e.preventDefault();
    var firstname = this.state.firstname.trim();
    var lastname = this.state.lastname.trim();
    var address = this.state.address.trim();
    var phonenumber = this.state.phonenumber.trim();
    var email = this.state.email.trim();
    var licensestate = this.state.licensestate.trim();
    var licensenum = this.state.licensenum.trim();
    var zip = this.state.zip.trim();
    var service = this.state.service.trim();
    var otherservice = this.state.otherservice;
    if (ziplist.indexOf(zip) == -1){
        alert ("“Sorry, we do not offer this service in your area.");
        this.setState({zip:''});
        return;
    }
    if (!firstname || !lastname || !address ||!phonenumber || !email || !licensestate || !licensenum || !zip
    || !service || !otherservice)
    {
      alert("Please fill the form completely")
      return;
    }
    this.props.onUserSubmit({firstname: firstname, lastname: lastname, address: address, phonenumber: phonenumber,
     email: email, licensestate: licensestate, licensenum:licensenum, zip:zip, service:service,
      otherservice:otherservice});
    this.setState({firstname: '', lastname: '', address:'', phonenumber:'', email:'', licensestate:'', licensenum:''
    , zip:'', service: '', otherservice: ''});
    otherservices = [];
  },
  render: function() {
    return (
      <form className="userForm" onSubmit={this.handleSubmit}>
        <div className="well">
        <h3>Personal Information</h3>
            <div>
                <label>First Name:</label>&nbsp;<input
                    type="text"
                    placeholder="First name"
                    value={this.state.firstname}
                    onChange={this.handleFirstNameChange}
                /></div><br />
            <div>
                <label>Last Name:</label>&nbsp;<input
                    type="text"
                    placeholder="Last name"
                    value={this.state.lastname}
                    onChange={this.handleLastNameChange}
                /></div><br />
            <div>
                <label>Address:</label>&nbsp;<input
                    type="text"
                    placeholder="Address (Street, City, State, Zip)"
                    value={this.state.address}
                    onChange={this.handleAddressChange}
                /></div><br />
            <div>
                <label>Phone Number:</label>&nbsp;<input
                    type="number"
                    placeholder="Phone Number (999)-999-9999"
                    value={this.state.phonenumber}
                    onChange={this.handlePhoneNumberChange}
                /></div><br />
            <div>
                <label>Email Address:</label>&nbsp;<input
                    type="text"
                    placeholder="Email Address"
                    value={this.state.email}
                    onChange={this.handleEmailAddressChange}
                /></div><br />
            <div>
                <label>Zip Code:</label>&nbsp;<input
                    type="number"
                    placeholder="Zip Code"
                    value={this.state.zip}
                    onChange={this.handleZipChange}
                /></div>
        </div><br></br>
        <div>
            <label>License Plate State and Number:</label>&nbsp;
                <select value={this.state.licensestate} onChange={this.handleLicensePlateStateChange}>
                    placeholder="State"
                    <option value="Select License State">Select License State</option>
                    <option value="IA">IA</option>
                    <option value="CA">CA</option>
                    <option value="MA">MA</option>
                    <option value="KA">KA</option>
                    <option value="FL">FL</option>
                    <option value="WS">WS</option>
                    <option value="IL">IL</option>
                </select> -&nbsp;
            <input
              type="number"
              placeholder="License Number (eg: 123456)"
              value={this.state.licensenum}
              onChange={this.handleLicensePlateNumChange}
            />
        </div>
        <h3>Select a Service</h3>
        <label>
            <input type="radio" name="myRadioInput" value="Conventional Oil Change – Most popular"
            onClick={this.handleServiceChange}/>
            <span>Conventional Oil Change – Most popular</span><br />

            <input type="radio" name="myRadioInput" value="Synthetic Blend Oil Change – Higher Quality"
            onClick={this.handleServiceChange}/>
            <span>Synthetic Blend Oil Change – Higher Quality</span><br />

            <input type="radio" name="myRadioInput" value="Full Synthetic Oil Change – Highest Quality"
            onClick={this.handleServiceChange}/>
            <span>Full Synthetic Oil Change – Highest Quality</span><br />
        </label>
        <h3>Select Other Services</h3>
        <div className="pure-control-group" >
            <label className="pure-checkbox" >
                <input type="checkbox" name="checkbox-multiple" value="Tire Rotation"
                onClick={this.handleOtherServiceChange}/> Tire Rotation
            </label><br />
            <label className="pure-checkbox">
                <input type="checkbox" name="checkbox-multiple" value="Wiper Change"
                onClick={this.handleOtherServiceChange}/> Wiper Change
            </label><br />
            <label className="pure-checkbox">
                <input type="checkbox" name="checkbox-multiple" value="Transmission Flush"
                onClick={this.handleOtherServiceChange}/> Transmission Flush
            </label><br />
            <label className="pure-checkbox">
                <input type="checkbox" name="checkbox-multiple" value="Filter Replacement"
                onClick={this.handleOtherServiceChange}/> Filter Replacement
            </label><br />
      </div><br></br>
        <input type="submit" value="Submit Request" />
      </form>
    );
  }
});

ReactDOM.render(
  <UserBox url="/users" pollInterval={2000} />,
  document.getElementById('data')
);
