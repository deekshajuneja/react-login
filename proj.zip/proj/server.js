var fs = require('fs');
var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var Alert = require('react-bootstrap/lib/Alert');
var app = express();
var USERDATA = path.join(__dirname, 'users.json');

app.set('port', (process.env.PORT || 8080));

app.use('/', express.static(path.join(__dirname, 'public')));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');

    res.setHeader('Cache-Control', 'no-cache');
    next();
});

app.get('/users', function(req, res) {
  fs.readFile(USERDATA, function(err, data) {
    if (err) {
      console.error(err);
      process.exit(1);
    }
    res.json(JSON.parse(data));
  });
});

app.post('/users', function(req, res) {
  fs.readFile(USERDATA, function(err, data) {
    if (err) {
      console.error(err);
      process.exit(1);
    }
    var users = JSON.parse(data);
    var newUser = {
      id: Date.now(),
      firstname: req.body.firstname,
      lastname: req.body.lastname,
      address: req.body.address,
      phonenumber: req.body.phonenumber,
      email: req.body.email,
      licensestate: req.body.licensestate,
      licensenum: req.body.licensenum,
      zip: req.body.zip,
      service:req.body.service,
      otherservice:req.body.otherservice
    };
    users.push(newUser);
    fs.writeFile(USERDATA, JSON.stringify(users, null, 20), function(err) {
      if (err) {
        console.error(err);
        process.exit(1);
      }
      res.json(users);
    });
  });
});


app.listen(app.get('port'), function() {
  console.log('Server started: http://localhost:' + app.get('port') + '/');
});
